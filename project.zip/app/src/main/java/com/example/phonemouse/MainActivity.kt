package com.example.phonemouse

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothHidDevice
import android.bluetooth.BluetoothHidDeviceAppSdpSettings
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import java.util.concurrent.Executors
import kotlin.math.roundToInt

@SuppressLint("MissingPermission", "ClickableViewAccessibility")
class MainActivity : Activity(), SensorEventListener {

    private var hid: BluetoothHidDevice? = null
    private var host: BluetoothDevice? = null
    private var buttons = 0
    private var sens = 1.5f
    private var airMode = false
    private var accX = 0f
    private var accY = 0f
    private lateinit var status: TextView
    private lateinit var sm: SensorManager
    private val executor = Executors.newSingleThreadExecutor()

    private val descriptor: ByteArray = intArrayOf(
        0x05, 0x01, 0x09, 0x02, 0xA1, 0x01, 0x09, 0x01, 0xA1, 0x00,
        0x05, 0x09, 0x19, 0x01, 0x29, 0x03, 0x15, 0x00, 0x25, 0x01,
        0x95, 0x03, 0x75, 0x01, 0x81, 0x02, 0x95, 0x01, 0x75, 0x05, 0x81, 0x03,
        0x05, 0x01, 0x09, 0x30, 0x09, 0x31, 0x09, 0x38,
        0x15, 0x81, 0x25, 0x7F, 0x75, 0x08, 0x95, 0x03, 0x81, 0x06,
        0xC0, 0xC0
    ).map { it.toByte() }.toByteArray()

    private val callback = object : BluetoothHidDevice.Callback() {
        override fun onAppStatusChanged(pluggedDevice: BluetoothDevice?, registered: Boolean) {
            runOnUiThread {
                status.text = if (registered) "Hazır. 'Tablete bağlan'a bas." else "Kayıt başarısız"
            }
        }

        override fun onConnectionStateChanged(device: BluetoothDevice?, state: Int) {
            runOnUiThread {
                if (state == BluetoothProfile.STATE_CONNECTED) {
                    host = device
                    status.text = "Bağlandı: " + (device?.name ?: "cihaz")
                } else if (state == BluetoothProfile.STATE_DISCONNECTED) {
                    host = null
                    status.text = "Bağlantı yok"
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        sm = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        buildUi()
        if (Build.VERSION.SDK_INT >= 31 &&
            checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(
                arrayOf(Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_ADVERTISE), 1
            )
        } else {
            initHid()
        }
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        initHid()
    }

    private fun initHid() {
        val adapter: BluetoothAdapter? = (getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter
        if (adapter == null) {
            status.text = "Bluetooth yok"
            return
        }
        adapter.getProfileProxy(this, object : BluetoothProfile.ServiceListener {
            override fun onServiceConnected(profile: Int, proxy: BluetoothProfile) {
                val h = proxy as BluetoothHidDevice
                hid = h
                val sdp = BluetoothHidDeviceAppSdpSettings(
                    "Telefon Mouse", "Mouse", "PhoneMouse",
                    BluetoothHidDevice.SUBCLASS1_MOUSE, descriptor
                )
                h.registerApp(sdp, null, null, executor, callback)
            }

            override fun onServiceDisconnected(profile: Int) {
                hid = null
            }
        }, BluetoothProfile.HID_DEVICE)
    }

    private fun send(dx: Int, dy: Int, wheel: Int = 0) {
        val h = hid ?: return
        val d = host ?: return
        val r = byteArrayOf(
            buttons.toByte(),
            dx.coerceIn(-127, 127).toByte(),
            dy.coerceIn(-127, 127).toByte(),
            wheel.coerceIn(-127, 127).toByte()
        )
        h.sendReport(d, 0, r)
    }

    private fun move(fx: Float, fy: Float) {
        accX += fx
        accY += fy
        val ix = accX.toInt()
        val iy = accY.toInt()
        if (ix != 0 || iy != 0) {
            accX -= ix
            accY -= iy
            send(ix, iy)
        }
    }

    private fun connectDialog() {
        val adapter = (getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter
        val list = adapter.bondedDevices.toList()
        if (list.isEmpty()) {
            status.text = "Önce 'Görünür yap'a bas, tabletten telefonu eşleştir"
            return
        }
        val names = list.map { it.name ?: it.address }.toTypedArray()
        AlertDialog.Builder(this).setTitle("Tableti seç").setItems(names) { _, i ->
            hid?.connect(list[i])
            status.text = "Bağlanıyor..."
        }.show()
    }

    private fun makeBtn(text: String, color: Int): TextView {
        val t = TextView(this)
        t.text = text
        t.setTextColor(Color.WHITE)
        t.textSize = 20f
        t.typeface = Typeface.DEFAULT_BOLD
        t.gravity = Gravity.CENTER
        t.setBackgroundColor(color)
        return t
    }

    private fun buildUi() {
        val dp = resources.displayMetrics.density
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Color.parseColor("#202124"))
        root.setPadding((8 * dp).toInt(), (24 * dp).toInt(), (8 * dp).toInt(), (8 * dp).toInt())

        status = TextView(this)
        status.text = "Başlatılıyor..."
        status.setTextColor(Color.WHITE)
        status.textSize = 16f
        root.addView(status)

        val row1 = LinearLayout(this)
        val b1 = Button(this)
        b1.text = "Görünür yap"
        b1.setOnClickListener {
            val i = Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE)
            i.putExtra(BluetoothAdapter.EXTRA_DISCOVERABLE_DURATION, 120)
            startActivity(i)
        }
        val b2 = Button(this)
        b2.text = "Tablete bağlan"
        b2.setOnClickListener { connectDialog() }
        row1.addView(b1, LinearLayout.LayoutParams(0, -2, 1f))
        row1.addView(b2, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(row1)

        val sw = Switch(this)
        sw.text = "Hava modu (jiroskop)"
        sw.setTextColor(Color.WHITE)
        sw.setOnCheckedChangeListener { _, on ->
            airMode = on
            val g = sm.getDefaultSensor(Sensor.TYPE_GYROSCOPE)
            if (on && g != null) sm.registerListener(this, g, SensorManager.SENSOR_DELAY_GAME)
            else sm.unregisterListener(this)
        }
        root.addView(sw)

        val sb = SeekBar(this)
        sb.max = 100
        sb.progress = 30
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) {
                sens = 0.5f + p / 20f
            }

            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        root.addView(sb)

        val pad = makeBtn("DOKUNMATİK ALAN\n(parmakla kaydır)", Color.parseColor("#3C4043"))
        var lx = 0f
        var ly = 0f
        pad.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { lx = e.x; ly = e.y }
                MotionEvent.ACTION_MOVE -> {
                    move((e.x - lx) * sens, (e.y - ly) * sens)
                    lx = e.x
                    ly = e.y
                }
            }
            true
        }
        root.addView(pad, LinearLayout.LayoutParams(-1, 0, 1f))

        val bottom = LinearLayout(this)
        val left = makeBtn("SOL", Color.parseColor("#1A73E8"))
        val wheel = makeBtn("TEKERLEK\n↑ ↓", Color.parseColor("#5F6368"))
        val right = makeBtn("SAĞ", Color.parseColor("#E8710A"))

        left.setOnTouchListener { _, e -> btn(e, 1); true }
        right.setOnTouchListener { _, e -> btn(e, 2); true }

        var wy = 0f
        var wacc = 0f
        wheel.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { wy = e.y; wacc = 0f }
                MotionEvent.ACTION_MOVE -> {
                    wacc += (wy - e.y) / (12 * dp)
                    wy = e.y
                    val steps = wacc.roundToInt()
                    if (steps != 0) {
                        wacc -= steps
                        send(0, 0, steps)
                    }
                }
            }
            true
        }

        bottom.addView(left, LinearLayout.LayoutParams(0, (170 * dp).toInt(), 1f))
        bottom.addView(wheel, LinearLayout.LayoutParams(0, (170 * dp).toInt(), 0.7f))
        bottom.addView(right, LinearLayout.LayoutParams(0, (170 * dp).toInt(), 1f))
        root.addView(bottom)
        setContentView(root)
    }

    private fun btn(e: MotionEvent, mask: Int) {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { buttons = buttons or mask; send(0, 0) }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { buttons = buttons and mask.inv(); send(0, 0) }
        }
    }

    override fun onSensorChanged(e: SensorEvent) {
        if (!airMode) return
        move(-e.values[2] * sens * 25f, -e.values[0] * sens * 25f)
    }

    override fun onAccuracyChanged(s: Sensor?, a: Int) {}

    override fun onDestroy() {
        super.onDestroy()
        sm.unregisterListener(this)
        hid?.unregisterApp()
    }
}
